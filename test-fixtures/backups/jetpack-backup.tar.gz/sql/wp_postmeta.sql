--
-- Table structure for table `wp_postmeta`
--

DROP TABLE IF EXISTS `wp_postmeta`;
CREATE TABLE `wp_postmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext DEFAULT NULL,
  PRIMARY KEY (`meta_id`),
  KEY `post_id` (`post_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `wp_postmeta`
--

INSERT INTO `wp_postmeta` VALUES (2,3,'_wp_page_template','default');
INSERT INTO `wp_postmeta` VALUES (3,8,'_edit_lock','1782303448:1');
INSERT INTO `wp_postmeta` VALUES (4,18,'_menu_item_type','post_type');
INSERT INTO `wp_postmeta` VALUES (5,18,'_menu_item_menu_item_parent',0);
INSERT INTO `wp_postmeta` VALUES (6,18,'_menu_item_object_id',6);
INSERT INTO `wp_postmeta` VALUES (7,18,'_menu_item_object','page');
INSERT INTO `wp_postmeta` VALUES (8,18,'_menu_item_target','');
INSERT INTO `wp_postmeta` VALUES (9,18,'_menu_item_classes','a:1:{i:0;s:0:"";}');
INSERT INTO `wp_postmeta` VALUES (10,18,'_menu_item_xfn','');
INSERT INTO `wp_postmeta` VALUES (11,18,'_menu_item_url','');
INSERT INTO `wp_postmeta` VALUES (12,19,'_menu_item_type','post_type');
INSERT INTO `wp_postmeta` VALUES (13,19,'_menu_item_menu_item_parent',0);
INSERT INTO `wp_postmeta` VALUES (14,19,'_menu_item_object_id',11);
INSERT INTO `wp_postmeta` VALUES (15,19,'_menu_item_object','page');
INSERT INTO `wp_postmeta` VALUES (16,19,'_menu_item_target','');
INSERT INTO `wp_postmeta` VALUES (17,19,'_menu_item_classes','a:1:{i:0;s:0:"";}');
INSERT INTO `wp_postmeta` VALUES (18,19,'_menu_item_xfn','');
INSERT INTO `wp_postmeta` VALUES (19,19,'_menu_item_url','');
INSERT INTO `wp_postmeta` VALUES (20,20,'_menu_item_type','post_type');
INSERT INTO `wp_postmeta` VALUES (21,20,'_menu_item_menu_item_parent',0);
INSERT INTO `wp_postmeta` VALUES (22,20,'_menu_item_object_id',16);
INSERT INTO `wp_postmeta` VALUES (23,20,'_menu_item_object','page');
INSERT INTO `wp_postmeta` VALUES (24,20,'_menu_item_target','');
INSERT INTO `wp_postmeta` VALUES (25,20,'_menu_item_classes','a:1:{i:0;s:0:"";}');
INSERT INTO `wp_postmeta` VALUES (26,20,'_menu_item_xfn','');
INSERT INTO `wp_postmeta` VALUES (27,20,'_menu_item_url','');
INSERT INTO `wp_postmeta` VALUES (28,4,'_wp_old_slug','navigation');

