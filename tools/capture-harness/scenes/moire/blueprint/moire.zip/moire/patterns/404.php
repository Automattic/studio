<?php
/**
 * Title: 404
 * Slug: moire/404
 * Inserter: no
 */
?>
<!-- wp:columns {"isStackedOnMobile":false,"metadata":{"name":"Content"},"style":{"spacing":{"padding":{"right":"var:preset|spacing|20","left":"var:preset|spacing|20","top":"var:preset|spacing|20","bottom":"var:preset|spacing|20"},"margin":{"top":"0","bottom":"0"}}}} -->
<div class="wp-block-columns is-not-stacked-on-mobile" style="margin-top:0;margin-bottom:0;padding-top:var(--wp--preset--spacing--20);padding-right:var(--wp--preset--spacing--20);padding-bottom:var(--wp--preset--spacing--20);padding-left:var(--wp--preset--spacing--20)"><!-- wp:column {"width":"15%","metadata":{"name":"Header"}} -->
<div class="wp-block-column" style="flex-basis:15%"><!-- wp:template-part {"slug":"header","tagName":"header"} /--></div>
<!-- /wp:column -->

<!-- wp:column {"width":"85%","metadata":{"name":"Content"}} -->
<div class="wp-block-column" style="flex-basis:85%"><!-- wp:spacer {"height":"7vw"} -->
<div style="height:7vw" aria-hidden="true" class="wp-block-spacer"></div>
<!-- /wp:spacer -->

<!-- wp:group {"tagName":"main","style":{"spacing":{"blockGap":"var:preset|spacing|40"},"dimensions":{"minHeight":"70vh"}},"layout":{"type":"default"}} -->
<main class="wp-block-group" style="min-height:70vh"><!-- wp:group {"align":"full","style":{"spacing":{"blockGap":"var:preset|spacing|20"}},"layout":{"type":"flex","orientation":"vertical"}} -->
<div class="wp-block-group alignfull"><!-- wp:heading {"textAlign":"left","align":"full","fontSize":"x-large"} -->
<h2 class="wp-block-heading alignfull has-text-align-left has-x-large-font-size" id="oops-that-page-can-t-be-found"><?php esc_html_e('Oops! That page can’t be found.', 'moire');?></h2>
<!-- /wp:heading -->

<!-- wp:paragraph {"className":"has-poppins-font-family","style":{"typography":{"textAlign":"left"}},"fontSize":"small"} -->
<p class="has-text-align-left has-poppins-font-family has-small-font-size"><?php esc_html_e('It looks like nothing was found at this location. Maybe try a search?', 'moire');?></p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->

<!-- wp:group {"metadata":{"name":"Search"},"style":{"spacing":{"padding":{"left":"0","right":"0"}}},"layout":{"type":"constrained","justifyContent":"left"}} -->
<div class="wp-block-group" style="padding-right:0;padding-left:0"><!-- wp:search {"label":"Search","showLabel":false,"buttonText":"\u003cstrong\u003eSearch\u003c/strong\u003e","style":{"border":{"radius":{"topLeft":"0px","topRight":"0px","bottomLeft":"0px","bottomRight":"0px"}},"typography":{"textTransform":"uppercase"}},"fontSize":"small"} /--></div>
<!-- /wp:group --></main>
<!-- /wp:group --></div>
<!-- /wp:column --></div>
<!-- /wp:columns -->

<!-- wp:template-part {"slug":"footer","tagName":"footer"} /-->