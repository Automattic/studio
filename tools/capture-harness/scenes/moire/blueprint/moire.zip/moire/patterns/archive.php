<?php
/**
 * Title: archive
 * Slug: moire/archive
 * Inserter: no
 */
?>
<!-- wp:group {"tagName":"main","metadata":{"name":"Archives"},"layout":{"type":"default"}} -->
<main class="wp-block-group"><!-- wp:columns {"isStackedOnMobile":false,"metadata":{"name":"Content"},"style":{"spacing":{"padding":{"right":"var:preset|spacing|20","left":"var:preset|spacing|20","top":"var:preset|spacing|20","bottom":"var:preset|spacing|20"},"margin":{"top":"0","bottom":"0"}}}} -->
<div class="wp-block-columns is-not-stacked-on-mobile" style="margin-top:0;margin-bottom:0;padding-top:var(--wp--preset--spacing--20);padding-right:var(--wp--preset--spacing--20);padding-bottom:var(--wp--preset--spacing--20);padding-left:var(--wp--preset--spacing--20)"><!-- wp:column {"width":"15%","metadata":{"name":"Header"}} -->
<div class="wp-block-column" style="flex-basis:15%"><!-- wp:template-part {"slug":"header","tagName":"header"} /--></div>
<!-- /wp:column -->

<!-- wp:column {"width":"85%","metadata":{"name":"Posts"}} -->
<div class="wp-block-column" style="flex-basis:85%"><!-- wp:group {"metadata":{"name":"Query Loop"},"style":{"dimensions":{"minHeight":"70vh"}},"layout":{"type":"default"}} -->
<div class="wp-block-group" style="min-height:70vh"><!-- wp:spacer {"height":"7vh"} -->
<div style="height:7vh" aria-hidden="true" class="wp-block-spacer"></div>
<!-- /wp:spacer -->

<!-- wp:query {"queryId":23,"query":{"perPage":10,"pages":0,"offset":0,"postType":"post","order":"desc","orderBy":"date","author":"","search":"","exclude":[],"sticky":"","inherit":true,"taxQuery":null,"parents":[],"format":[]}} -->
<div class="wp-block-query"><!-- wp:query-title {"type":"archive","level":2,"style":{"spacing":{"padding":{"bottom":"var:preset|spacing|40"}}},"fontSize":"x-large"} /-->

<!-- wp:post-template -->
<!-- wp:columns -->
<div class="wp-block-columns"><!-- wp:column {"width":"10%"} -->
<div class="wp-block-column" style="flex-basis:10%"><!-- wp:post-featured-image {"isLink":true,"aspectRatio":"1","style":{"layout":{"selfStretch":"fill","flexSize":null}}} /--></div>
<!-- /wp:column -->

<!-- wp:column {"verticalAlignment":"center","width":"66.66%"} -->
<div class="wp-block-column is-vertically-aligned-center" style="flex-basis:66.66%"><!-- wp:group {"style":{"spacing":{"blockGap":"var:preset|spacing|20"}},"layout":{"type":"flex","orientation":"vertical"}} -->
<div class="wp-block-group"><!-- wp:post-title {"isLink":true} /-->

<!-- wp:post-date /--></div>
<!-- /wp:group --></div>
<!-- /wp:column --></div>
<!-- /wp:columns -->
<!-- /wp:post-template -->

<!-- wp:query-no-results -->
<!-- wp:paragraph {"placeholder":"Add text or blocks that will display when a query returns no results.","style":{"spacing":{"padding":{"bottom":"var:preset|spacing|40","top":"var:preset|spacing|20"}}},"fontSize":"small","fontFamily":"poppins"} -->
<p class="has-poppins-font-family has-small-font-size" style="padding-top:var(--wp--preset--spacing--20);padding-bottom:var(--wp--preset--spacing--40)"><?php esc_html_e('Sorry, but nothing matched your search terms. Please try again with some different keywords.', 'moire');?></p>
<!-- /wp:paragraph -->
<!-- /wp:query-no-results -->

<!-- wp:query-pagination {"layout":{"type":"flex","justifyContent":"space-between"}} -->
<!-- wp:query-pagination-previous /-->

<!-- wp:query-pagination-numbers /-->

<!-- wp:query-pagination-next /-->
<!-- /wp:query-pagination -->

<!-- wp:spacer {"height":"var:preset|spacing|50"} -->
<div style="height:var(--wp--preset--spacing--50)" aria-hidden="true" class="wp-block-spacer"></div>
<!-- /wp:spacer --></div>
<!-- /wp:query --></div>
<!-- /wp:group --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></main>
<!-- /wp:group -->

<!-- wp:template-part {"slug":"footer","tagName":"footer"} /-->