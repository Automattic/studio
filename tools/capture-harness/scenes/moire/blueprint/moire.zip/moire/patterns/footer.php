<?php
/**
 * Title: footer
 * Slug: moire/footer
 * Inserter: no
 */
?>
<!-- wp:group {"style":{"spacing":{"padding":{"top":"var:preset|spacing|20","bottom":"var:preset|spacing|20","left":"var:preset|spacing|20","right":"var:preset|spacing|20"},"margin":{"top":"0","bottom":"0"}}},"backgroundColor":"secondary","layout":{"type":"default"}} -->
<div class="wp-block-group has-secondary-background-color has-background" style="margin-top:0;margin-bottom:0;padding-top:var(--wp--preset--spacing--20);padding-right:var(--wp--preset--spacing--20);padding-bottom:var(--wp--preset--spacing--20);padding-left:var(--wp--preset--spacing--20)"><!-- wp:navigation {"textColor":"primary","overlayMenu":"never","style":{"typography":{"fontStyle":"normal","fontWeight":"600"}},"fontSize":"small","layout":{"type":"flex","justifyContent":"space-between"}} /-->

<!-- wp:spacer {"height":"8vh"} -->
<div style="height:8vh" aria-hidden="true" class="wp-block-spacer"></div>
<!-- /wp:spacer -->

<!-- wp:heading {"style":{"typography":{"lineHeight":"0.8"}},"fitText":true} -->
<h2 class="wp-block-heading has-fit-text" style="line-height:0.8"><?php esc_html_e('Rhea Moire', 'moire');?></h2>
<!-- /wp:heading --></div>
<!-- /wp:group -->