<?php
/**
 * Title: Link in Bio: Cover Image and Socials
 * Slug: moire/link-in-bio-cover-image-socials
 * Inserter: yes
 * Categories: featured
 */
?>
<!-- wp:group {"metadata":{"name":"Link in Bio: Cover Image"},"style":{"spacing":{"padding":{"top":"var:preset|spacing|20","bottom":"var:preset|spacing|20","left":"var:preset|spacing|20","right":"var:preset|spacing|20"},"margin":{"top":"0","bottom":"0"}},"dimensions":{"minHeight":"100vh"}},"layout":{"type":"default"}} -->
<div class="wp-block-group" style="min-height:100vh;margin-top:0;margin-bottom:0;padding-top:var(--wp--preset--spacing--20);padding-right:var(--wp--preset--spacing--20);padding-bottom:var(--wp--preset--spacing--20);padding-left:var(--wp--preset--spacing--20)"><!-- wp:heading {"style":{"typography":{"lineHeight":"0.8"}},"fitText":true} -->
<h2 class="wp-block-heading has-fit-text" style="line-height:0.8"><?php esc_html_e('Rhea Moire', 'moire');?></h2>
<!-- /wp:heading -->

<!-- wp:site-tagline {"style":{"elements":{"link":{"color":{"text":"var:preset|color|primary"}}}},"textColor":"primary"} /-->

<!-- wp:cover {"url":"<?php echo esc_url( get_template_directory_uri() ); ?>/assets/images/author-photo-1-scaled.jpg","dimRatio":0,"isUserOverlayColor":true,"minHeight":75,"minHeightUnit":"vh","sizeSlug":"full","layout":{"type":"constrained"}} -->
<div class="wp-block-cover" style="min-height:75vh"><img class="wp-block-cover__image-background size-full" alt="" src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/images/author-photo-1-scaled.jpg" data-object-fit="cover"/><span aria-hidden="true" class="wp-block-cover__background has-background-dim-0 has-background-dim"></span><div class="wp-block-cover__inner-container"><!-- wp:paragraph {"align":"center","placeholder":"Write title…","fontSize":"large"} -->
<p class="has-text-align-center has-large-font-size"></p>
<!-- /wp:paragraph --></div></div>
<!-- /wp:cover -->

<!-- wp:navigation {"textColor":"primary","overlayMenu":"never","style":{"typography":{"fontStyle":"normal","fontWeight":"600"}},"fontSize":"small","layout":{"type":"flex","justifyContent":"space-between"}} /--></div>
<!-- /wp:group -->