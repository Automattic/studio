== Moire ==

Contributors: Automattic
Requires at least: 6.8
Tested up to: 6.8
Requires PHP: 7.2
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html


== Description ==

Moire is a theme for sartorial storytellers — writers, editors, and thinkers who want their words to stand out with clarity and conviction. Its design is bold yet minimal, contemporary yet timeless: thick, confident sans-serif headings paired with an elegant serif body font create a striking visual rhythm that feels unmistakably editorial.

Built on a clean white canvas, Moire removes noise and lets your content take center stage — whether you’re dissecting runway silhouettes, analyzing tailoring, or sharing personal style essays. Every layout is intentional, refined, and opinionated, giving your writing the same presence as a magazine spread.

Moire also includes dedicated “link in bio” patterns, perfect for highlighting your latest stories, collaborations, or social channels in a streamlined, visual format. Designed for writers who value structure, tone, and visual impact, Moire turns your blog into a modern editorial destination.


== Changelog ==

= 1.0.1 =
* fix: remove hardcoded datetime from post-date blocks in 6 themes (THEME-180)

= 1.0.0 =
* Initial release


== Copyright ==

Moire WordPress Theme, (C) 2025 Automattic
Moire is distributed under the terms of the GNU GPL.

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

== Fonts ==

Poppins Font
Copyright 2020 The Poppins Project Authors (https://github.com/itfoundry/Poppins)
This Font Software is licensed under the SIL Open Font License, Version 1.1 . This license is copied below, and is also available with a FAQ at: https://openfontlicense.org
License URL: http://scripts.sil.org/OFL 
-- End of Poppins Font credits --

Libertinus Serif Font
Copyright © 2012-2024 The Libertinus Project Authors, with Reserved Font Name "Linux Libertine", "Biolinum", "STIX Fonts".
This Font Software is licensed under the SIL Open Font License, Version 1.1 . This license is copied below, and is also available with a FAQ at: https://openfontlicense.org
License URL: http://scripts.sil.org/OFL 
-- End of Poppins Font credits --

== Images ==

Image in theme screenshot:
License: CC0 1.0 Universal (CC0 1.0)
License URL: https://creativecommons.org/publicdomain/zero/1.0/
Source: Generated with AI on Visual Electric, released as CC0.
